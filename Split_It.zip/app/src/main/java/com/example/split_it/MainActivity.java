package com.example.split_it;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText etn1;
    private EditText etn2;
    private TextView    Result;
    private EditText etn3;
    private EditText etn4;
    private TextView    Result3;
    private TextView    Result4;
    private EditText etn5;
    private EditText etn6;
    private EditText etn7;
    private EditText etn8;
    private EditText etn9;
    private TextView    Result5;
    private TextView    Result6;
    private TextView    Result7;
    private TextView    Result8;
    private TextView    Result9;
    private TextView    Result10;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etn1 = (EditText) findViewById(R.id.etn1);
        etn2 = (EditText) findViewById(R.id.etn2);
        Result = (TextView) findViewById(R.id.result1);
        etn3 = (EditText) findViewById(R.id.etn3);
        etn4 = (EditText) findViewById(R.id.etn4);
        etn5 = (EditText) findViewById(R.id.etn5);
        etn6 = (EditText) findViewById(R.id.etn6);
        etn7 = (EditText) findViewById(R.id.etn7);
        etn8 = (EditText) findViewById(R.id.etn8);
        etn9 = (EditText) findViewById(R.id.etn9);
        Result3 = (TextView) findViewById(R.id.result3);
        Result4 = (TextView) findViewById(R.id.result4);
        Result5 = (TextView) findViewById(R.id.result5);
        Result6 = (TextView) findViewById(R.id.result6);
        Result7 = (TextView) findViewById(R.id.result7);
        Result8 = (TextView) findViewById(R.id.result8);
        Result9 = (TextView) findViewById(R.id.result9);
        Result10 = (TextView) findViewById(R.id.total);

    }

    public void multi(View view) {
        float n1 = Float.parseFloat(etn1.getText().toString());
        float n2 = Float.parseFloat(etn2.getText().toString());
        double multi = n1+(n1*0.0875)+(n1*n2*0.01);
        Result.setText(String.valueOf(multi));
        float n3 = Float.parseFloat(etn3.getText().toString());
        float n4 = Float.parseFloat(etn4.getText().toString());
        double multi3 = n3+(n3*0.0875)+(n3*n2*0.01);
        double multi4 = n4+(n4*0.0875)+(n4*n2*0.01);
        Result3.setText(String.valueOf(multi3));
        Result4.setText(String.valueOf(multi4));
        float n5 = Float.parseFloat(etn5.getText().toString());
        float n6 = Float.parseFloat(etn6.getText().toString());
        float n7 = Float.parseFloat(etn7.getText().toString());
        float n8 = Float.parseFloat(etn8.getText().toString());
        float n9 = Float.parseFloat(etn9.getText().toString());
        double multi5 = n5+(n5*0.0875)+(n5*n2*0.01);
        double multi6 = n6+(n6*0.0875)+(n6*n2*0.01);
        double multi7 = n7+(n7*0.0875)+(n7*n2*0.01);
        double multi8 = n8+(n8*0.0875)+(n8*n2*0.01);
        double multi9 = n9+(n9*0.0875)+(n9*n2*0.01);
        double multi10 = multi+multi3+multi4+multi5+multi6+multi7+multi8+multi9;
        Result5.setText(String.valueOf(multi5));
        Result6.setText(String.valueOf(multi6));
        Result7.setText(String.valueOf(multi7));
        Result8.setText(String.valueOf(multi8));
        Result9.setText(String.valueOf(multi9));
        Result10.setText(String.valueOf(multi10));



    }
}